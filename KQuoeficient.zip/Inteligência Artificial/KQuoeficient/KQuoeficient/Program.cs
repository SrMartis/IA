﻿using System;
using System.IO;
using Microsoft.ML;


namespace KQuoeficient
{
    class Program
    {
        static readonly string _trainDataPath = Path.Combine(Environment.CurrentDirectory, "Dados", "train.csv");
        static readonly string _testDataPath = Path.Combine(Environment.CurrentDirectory, "Dados",  "test.csv");
        static readonly string _modelPath = Path.Combine(Environment.CurrentDirectory, "Dados", "model.zip");
        static void Main(string[] args)
        {
            MLContext mlContext = new MLContext(seed: 0);

            var model = Train()
            
        }
    }
}
