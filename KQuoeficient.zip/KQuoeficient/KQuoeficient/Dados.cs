﻿using Microsoft.ML.Data;

namespace KQuoeficient
{
    class Dados
    {
        [LoadColumn(0)]
        public float distance;

        [LoadColumn(1)]
        public float mass;

        [LoadColumn(2)]
        public float k_real;
                
    }

    public class K_Estimado
    {
        [ColumnName("k - real")]
        public float k_real;
    }
}
