﻿using System;
using System.IO;
using Microsoft.ML;

namespace KQuoeficient
{
    class Program
    {
        static readonly string _trainDataPath = Path.Combine(Environment.CurrentDirectory, "Dados", "train.csv");
        static readonly string _testDataPath = Path.Combine(Environment.CurrentDirectory, "Dados",  "test.csv");
        static readonly string _modelPath = Path.Combine(Environment.CurrentDirectory, "Dados", "model.zip");
    
        static void Main(string[] args)
        {
            MLContext mlContext = new MLContext(seed: 0);

            var model = Train(mlContext, _trainDataPath); //Traina o modelo com os dados existentes
            Evaluate(mlContext, model);
            TestSinglePrediction(mlContext, model);
        }
        public static ITransformer Train(MLContext mLContext, string dataPath) {
            IDataView dataView = mLContext.Data.LoadFromTextFile<Dados>(dataPath, hasHeader: true, separatorChar:';');
//A linha acima carrega arquivos de texto, dados de bases do SQL, dados tabulares em tempo real de execução
            var pipeline = mLContext.Transforms.CopyColumns(outputColumnName: "Label", inputColumnName: "k")
            .Append(mLContext.Transforms.Categorical.OneHotEncoding(outputColumnName: "DistanceEncoded", inputColumnName: "distance"))
            .Append(mLContext.Transforms.Categorical.OneHotEncoding(outputColumnName: "MassEncoded", inputColumnName: "mass"))
            .Append(mLContext.Transforms.Concatenate("Features", "DistanceEncoded", "MassEncoded"))
            .Append(mLContext.Regression.Trainers.FastTree());

            var model = pipeline.Fit(dataView);
            return model;
        }
        
        private static void Evaluate(MLContext mLContext, ITransformer model){
            IDataView dataView = mLContext.Data.LoadFromTextFile<Dados>(_testDataPath, hasHeader:true, separatorChar: ';');
            var predictions = model.Transform(dataView);
            var metrics = mLContext.Regression.Evaluate(predictions, "Label", "Score");

            Console.WriteLine();
Console.WriteLine($"*************************************************");
Console.WriteLine($"*       Model quality metrics evaluation         ");
Console.WriteLine($"*------------------------------------------------");
Console.WriteLine($"*       RSquared Score:      {metrics.RSquared:#.##}");
Console.WriteLine($"*       Mean Squared Error:      {metrics.MeanSquaredError:#.##}");
        }

        private static void TestSinglePrediction(MLContext mLContext, ITransformer model){
            var predictionFunction = mLContext.Model.CreatePredictionEngine<Dados, K_Estimado>(model);
            var testExample = new Dados()
            {        
                //0.21150;0.32000;14,843                
                //0.1575;0.275;17.129
                //0.4013;0.6250;15.279
                //0.4263;0.6500;14.957
                distance = 0.4013F,
                mass = 0.6250F,
                k = 0 // Valor a ser previsto
            };

            var prediction = predictionFunction.Predict(testExample);

            Console.WriteLine($"**********************************************************************");
Console.WriteLine($"Predicted fare: {prediction.k:0.####}, actual : 15.279");
Console.WriteLine($"**********************************************************************");
        }


    }
}
