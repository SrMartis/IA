﻿using Microsoft.ML.Data;

namespace KQuoeficient
{
    public class Dados
    {
        [LoadColumn(0)]
        public float distance;

        [LoadColumn(1)]
        public float mass;

        [LoadColumn(2)]
        public float k;
                
    }
    public class K_Estimado
    {
        [ColumnName("Score")]
        public float k;
    }
}
